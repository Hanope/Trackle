package com.example.yep.myapplication.model;

/**
 * Created by seowo on 2017-09-16.
 */

public class SearchData {
    public String keyword;

    public SearchData(String keyword) {
        this.keyword = keyword;
    }
}
